import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi_web/sqflite_ffi_web.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  if (kIsWeb) {
    databaseFactory = databaseFactoryFfiWeb;
  }

  runApp(const MeuApp());
}

class Usuario {
  final int? id;
  final String nome;
  final String email;
  final String senha;

  Usuario({this.id, required this.nome, required this.email, required this.senha});

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'nome': nome,
        'email': email,
        'senha': senha,
      };

  factory Usuario.fromMap(Map<String, dynamic> map) => Usuario(
        id: map['id'] as int?,
        nome: map['nome'] as String,
        email: map['email'] as String,
        senha: map['senha'] as String,
      );
}

class Produto {
  final int? id;
  final String nome;
  final String categoria;
  final int quantidade;
  final double preco;

  Produto({
    this.id,
    required this.nome,
    required this.categoria,
    required this.quantidade,
    required this.preco,
  });

  bool get estoqueBaixo => quantidade <= 3;

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'nome': nome,
        'categoria': categoria,
        'quantidade': quantidade,
        'preco': preco,
      };

  factory Produto.fromMap(Map<String, dynamic> map) => Produto(
        id: map['id'] as int?,
        nome: map['nome'] as String,
        categoria: map['categoria'] as String,
        quantidade: map['quantidade'] as int,
        preco: (map['preco'] as num).toDouble(),
      );
}

class Banco {
  static Database? _db;

  static Future<Database> get instancia async {
    _db ??= await _abrir();
    return _db!;
  }

  static Future<Database> _abrir() async {
    return openDatabase(
      'estoque.db',
      version: 1,
      onCreate: (db, versao) async {
        await db.execute('''
          CREATE TABLE usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            senha TEXT NOT NULL
          )
        ''');

        await db.execute('''
          CREATE TABLE produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            categoria TEXT NOT NULL,
            quantidade INTEGER NOT NULL,
            preco REAL NOT NULL
          )
        ''');
      },
    );
  }
}

class UsuarioService {
  Future<bool> emailExiste(String email) async {
    final db = await Banco.instancia;
    print('SELECT -> Verificando e-mail: $email');
    final resultado = await db.query('usuarios', where: 'email = ?', whereArgs: [email]);
    return resultado.isNotEmpty;
  }

  Future<String?> cadastrar(Usuario usuario) async {
    final db = await Banco.instancia;

    if (await emailExiste(usuario.email)) {
      print('SELECT -> E-mail já cadastrado: ${usuario.email}');
      return 'E-mail já cadastrado.';
    }

    await db.insert('usuarios', usuario.toMap());
    print('INSERT -> Usuário cadastrado: ${usuario.nome}');
    return null;
  }

  Future<Usuario?> buscar(String email, String senha) async {
    final db = await Banco.instancia;

    print('SELECT -> Procurando usuário: $email');

    final resultado = await db.query(
      'usuarios',
      where: 'email = ? AND senha = ?',
      whereArgs: [email, senha],
    );

    if (resultado.isEmpty) {
      print('SELECT -> Usuário não encontrado');
      return null;
    }

    final usuario = Usuario.fromMap(resultado.first);
    print('SELECT -> Usuário encontrado: ${usuario.nome}');
    return usuario;
  }
}

class ProdutoService {
  Future<void> cadastrar(Produto produto) async {
    final db = await Banco.instancia;
    await db.insert('produtos', produto.toMap());
    print('INSERT -> Produto cadastrado: ${produto.nome}');
  }

  Future<List<Produto>> listar() async {
    final db = await Banco.instancia;
    final resultado = await db.query('produtos', orderBy: 'id');

    print('SELECT -> Produtos encontrados:');
    for (final linha in resultado) {
      print({
        'id': linha['id'],
        'nome': linha['nome'],
        'quantidade': linha['quantidade'],
      });
    }

    return resultado.map(Produto.fromMap).toList();
  }

  Future<void> atualizarQuantidade(Produto produto, int novaQuantidade) async {
    final db = await Banco.instancia;

    await db.update(
      'produtos',
      {'quantidade': novaQuantidade},
      where: 'id = ?',
      whereArgs: [produto.id],
    );

    print('UPDATE -> ${produto.nome}');
    print('Quantidade anterior: ${produto.quantidade}');
    print('Nova quantidade: $novaQuantidade');
  }

  Future<void> excluir(Produto produto) async {
    final db = await Banco.instancia;
    await db.delete('produtos', where: 'id = ?', whereArgs: [produto.id]);
    print('DELETE -> Produto excluído: ${produto.nome}');
  }

  Future<void> mostrarProdutosNoTerminal() async {
    final db = await Banco.instancia;

    final produtos = await db.query('produtos');

    print('===== PRODUTOS NO BANCO =====');

    for (final produto in produtos) {
      print(produto);
    }
  }
}

class UsuarioProvider extends ChangeNotifier {
  final UsuarioService _service = UsuarioService();

  Usuario? usuarioLogado;
  String? erro;
  bool carregando = false;

  Future<bool> cadastrar({
    required String nome,
    required String email,
    required String senha,
  }) async {
    carregando = true;
    erro = null;
    notifyListeners();

    final mensagem = await _service.cadastrar(
      Usuario(nome: nome, email: email, senha: senha),
    );

    erro = mensagem;
    carregando = false;
    notifyListeners();

    return mensagem == null;
  }

  Future<bool> login(String email, String senha) async {
    carregando = true;
    erro = null;
    notifyListeners();

    final usuario = await _service.buscar(email, senha);

    if (usuario == null) {
      erro = 'E-mail ou senha incorretos.';
    } else {
      usuarioLogado = usuario;
    }

    carregando = false;
    notifyListeners();

    return usuario != null;
  }

  void sair() {
    usuarioLogado = null;
    erro = null;
    notifyListeners();
  }
}

class ProdutoProvider extends ChangeNotifier {
  final ProdutoService _service = ProdutoService();

  List<Produto> produtos = [];
  bool carregando = false;

  Future<void> carregar() async {
    carregando = true;
    notifyListeners();

    produtos = await _service.listar();

    carregando = false;
    notifyListeners();
  }

  Future<void> cadastrar({
    required String nome,
    required String categoria,
    required int quantidade,
    required double preco,
  }) async {
    await _service.cadastrar(
      Produto(nome: nome, categoria: categoria, quantidade: quantidade, preco: preco),
    );
    await carregar();
  }

  Future<void> alterarQuantidade(Produto produto, int variacao) async {
    final nova = produto.quantidade + variacao;
    if (nova < 0) return;

    await _service.atualizarQuantidade(produto, nova);
    await carregar();
  }

  Future<void> excluir(Produto produto) async {
    await _service.excluir(produto);
    await carregar();
  }

  Future<void> mostrarProdutosNoTerminal() => _service.mostrarProdutosNoTerminal();
}

class MeuApp extends StatelessWidget {
  const MeuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => UsuarioProvider()),
        ChangeNotifierProvider(create: (_) => ProdutoProvider()),
      ],
      child: MaterialApp(
        title: 'Controle de Estoque',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
          useMaterial3: true,
        ),
        home: const LoginPage(),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _email = TextEditingController();
  final _senha = TextEditingController();

  @override
  void dispose() {
    _email.dispose();
    _senha.dispose();
    super.dispose();
  }

  Future<void> _entrar() async {
    final provider = context.read<UsuarioProvider>();
    final ok = await provider.login(_email.text.trim(), _senha.text);

    if (!mounted) return;

    if (ok) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const HomePage()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(provider.erro ?? 'E-mail ou senha incorretos.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<UsuarioProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('ÁREA RESTRITA')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 380),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'ÁREA RESTRITA',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 24),
                TextField(
                  controller: _email,
                  decoration: const InputDecoration(
                    labelText: 'E-mail',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _senha,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Senha',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),
                FilledButton(
                  onPressed: provider.carregando ? null : _entrar,
                  child: const Text('ENTRAR'),
                ),
                const SizedBox(height: 16),
                const Text('Ainda não possui conta?', textAlign: TextAlign.center),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const CadastroPage()),
                    );
                  },
                  child: const Text('CRIAR CONTA'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CadastroPage extends StatefulWidget {
  const CadastroPage({super.key});

  @override
  State<CadastroPage> createState() => _CadastroPageState();
}

class _CadastroPageState extends State<CadastroPage> {
  final _nome = TextEditingController();
  final _email = TextEditingController();
  final _senha = TextEditingController();

  @override
  void dispose() {
    _nome.dispose();
    _email.dispose();
    _senha.dispose();
    super.dispose();
  }

  Future<void> _cadastrar() async {
    final nome = _nome.text.trim();
    final email = _email.text.trim();
    final senha = _senha.text;

    if (nome.isEmpty || email.isEmpty || senha.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Preencha todos os campos.')),
      );
      return;
    }

    final provider = context.read<UsuarioProvider>();
    final ok = await provider.cadastrar(nome: nome, email: email, senha: senha);

    if (!mounted) return;

    if (ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Usuário cadastrado com sucesso.')),
      );
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(provider.erro ?? 'Não foi possível cadastrar.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<UsuarioProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('CRIAR CONTA')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 380),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: _nome,
                  decoration: const InputDecoration(
                    labelText: 'Nome',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _email,
                  decoration: const InputDecoration(
                    labelText: 'E-mail',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _senha,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Senha',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),
                FilledButton(
                  onPressed: provider.carregando ? null : _cadastrar,
                  child: const Text('CADASTRAR'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final usuario = context.watch<UsuarioProvider>().usuarioLogado;

    return Scaffold(
      appBar: AppBar(title: const Text('CONTROLE DE ESTOQUE')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 380),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'Olá, ${usuario?.nome ?? ''}!',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                const Text('CONTROLE DE ESTOQUE', textAlign: TextAlign.center),
                const SizedBox(height: 28),
                FilledButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const EstoquePage()),
                    );
                  },
                  child: const Text('VER PRODUTOS'),
                ),
                const SizedBox(height: 12),
                FilledButton.tonal(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const CadastroProdutoPage()),
                    );
                  },
                  child: const Text('CADASTRAR PRODUTO'),
                ),
                const SizedBox(height: 12),
                OutlinedButton(
                  onPressed: () {
                    context.read<UsuarioProvider>().sair();
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (_) => const LoginPage()),
                      (rota) => false,
                    );
                  },
                  child: const Text('SAIR'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CadastroProdutoPage extends StatefulWidget {
  const CadastroProdutoPage({super.key});

  @override
  State<CadastroProdutoPage> createState() => _CadastroProdutoPageState();
}

class _CadastroProdutoPageState extends State<CadastroProdutoPage> {
  final _nome = TextEditingController();
  final _categoria = TextEditingController();
  final _quantidade = TextEditingController();
  final _preco = TextEditingController();

  @override
  void dispose() {
    _nome.dispose();
    _categoria.dispose();
    _quantidade.dispose();
    _preco.dispose();
    super.dispose();
  }

  Future<void> _cadastrar() async {
    final nome = _nome.text.trim();
    final categoria = _categoria.text.trim();
    final quantidade = int.tryParse(_quantidade.text.trim());
    final preco = double.tryParse(_preco.text.trim().replaceAll(',', '.'));

    if (nome.isEmpty || categoria.isEmpty || quantidade == null || preco == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Preencha todos os campos corretamente.')),
      );
      return;
    }

    await context.read<ProdutoProvider>().cadastrar(
          nome: nome,
          categoria: categoria,
          quantidade: quantidade,
          preco: preco,
        );

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Produto cadastrado: $nome')),
    );

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('CADASTRAR PRODUTO')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 380),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: _nome,
                  decoration: const InputDecoration(
                    labelText: 'Nome',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _categoria,
                  decoration: const InputDecoration(
                    labelText: 'Categoria',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _quantidade,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Quantidade',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _preco,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Preço',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),
                FilledButton(
                  onPressed: _cadastrar,
                  child: const Text('CADASTRAR PRODUTO'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class EstoquePage extends StatefulWidget {
  const EstoquePage({super.key});

  @override
  State<EstoquePage> createState() => _EstoquePageState();
}

class _EstoquePageState extends State<EstoquePage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ProdutoProvider>().carregar();
    });
  }

  String _formatarPreco(double preco) {
    return 'R\$ ${preco.toStringAsFixed(2).replaceAll('.', ',')}';
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ProdutoProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('ESTOQUE'),
        actions: [
          IconButton(
            tooltip: 'Mostrar produtos no terminal',
            onPressed: provider.mostrarProdutosNoTerminal,
            icon: const Icon(Icons.terminal),
          ),
        ],
      ),
      body: provider.carregando && provider.produtos.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : provider.produtos.isEmpty
              ? const Center(child: Text('Nenhum produto cadastrado.'))
              : ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: provider.produtos.length,
                  separatorBuilder: (_, __) => const Divider(height: 24),
                  itemBuilder: (context, indice) {
                    final produto = provider.produtos[indice];
                    return ProdutoItem(
                      produto: produto,
                      preco: _formatarPreco(produto.preco),
                    );
                  },
                ),
    );
  }
}

class ProdutoItem extends StatelessWidget {
  const ProdutoItem({super.key, required this.produto, required this.preco});

  final Produto produto;
  final String preco;

  @override
  Widget build(BuildContext context) {
    final provider = context.read<ProdutoProvider>();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          produto.nome,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        Text(produto.categoria),
        Text(preco),
        if (produto.estoqueBaixo)
          Container(
            margin: const EdgeInsets.only(top: 6),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.red.shade100,
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              'ESTOQUE BAIXO',
              style: TextStyle(
                color: Colors.red.shade900,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        const SizedBox(height: 8),
        Row(
          children: [
            IconButton(
              onPressed: () => provider.alterarQuantidade(produto, -1),
              icon: const Icon(Icons.remove),
            ),
            Text(
              'Quantidade: ${produto.quantidade}',
              style: const TextStyle(fontSize: 16),
            ),
            IconButton(
              onPressed: () => provider.alterarQuantidade(produto, 1),
              icon: const Icon(Icons.add),
            ),
            const Spacer(),
            TextButton.icon(
              onPressed: () => provider.excluir(produto),
              icon: const Icon(Icons.delete_outline),
              label: const Text('EXCLUIR'),
            ),
          ],
        ),
      ],
    );
  }
}
