import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/voo.dart';
import '../providers/voo_provider.dart';
import 'detalhes_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late final TextEditingController _aeroportoController;

  @override
  void initState() {
    super.initState();
    final provider = context.read<VooProvider>();
    _aeroportoController = TextEditingController(text: provider.aeroporto);
    // Primeira busca assim que a tela abre (aeroporto padrão: SBGR).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      provider.buscarVoos();
    });
  }

  @override
  void dispose() {
    _aeroportoController.dispose();
    super.dispose();
  }

  void _buscar() {
    FocusScope.of(context).unfocus();
    context.read<VooProvider>().buscarVoos(novoAeroporto: _aeroportoController.text);
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<VooProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'RASPAVOO',
          style: TextStyle(letterSpacing: 4, fontWeight: FontWeight.w800),
        ),
      ),
      body: Column(
        children: [
          _Filtros(
            controller: _aeroportoController,
            provider: provider,
            onBuscar: _buscar,
          ),
          const Divider(height: 1),
          Expanded(child: _Corpo(provider: provider)),
        ],
      ),
    );
  }
}

class _Filtros extends StatelessWidget {
  const _Filtros({
    required this.controller,
    required this.provider,
    required this.onBuscar,
  });

  final TextEditingController controller;
  final VooProvider provider;
  final VoidCallback onBuscar;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: controller,
                  textCapitalization: TextCapitalization.characters,
                  maxLength: 4,
                  decoration: const InputDecoration(
                    labelText: 'Aeroporto (ICAO)',
                    hintText: 'Ex.: SBGR',
                    counterText: '',
                    border: OutlineInputBorder(),
                  ),
                  onSubmitted: (_) => onBuscar(),
                ),
              ),
              const SizedBox(width: 12),
              FilledButton(
                onPressed: provider.carregando ? null : onBuscar,
                child: const Text('Buscar'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SegmentedButton<TipoVoo>(
            segments: const [
              ButtonSegment(value: TipoVoo.todos, label: Text('Todos')),
              ButtonSegment(value: TipoVoo.chegadas, label: Text('Chegadas')),
              ButtonSegment(value: TipoVoo.partidas, label: Text('Partidas')),
            ],
            selected: {provider.tipo},
            onSelectionChanged: (selecao) {
              provider.buscarVoos(novoTipo: selecao.first);
            },
          ),
        ],
      ),
    );
  }
}

class _Corpo extends StatelessWidget {
  const _Corpo({required this.provider});

  final VooProvider provider;

  @override
  Widget build(BuildContext context) {
    // 1) Carregando.
    if (provider.carregando) {
      return const Center(child: CircularProgressIndicator());
    }

    // 2) Erro (API não respondeu, aeroporto inválido, etc.).
    if (provider.erro != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.wifi_off_rounded, size: 40, color: Colors.redAccent),
              const SizedBox(height: 12),
              Text(
                provider.erro!,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 16),
              OutlinedButton(
                onPressed: () => provider.buscarVoos(),
                child: const Text('Tentar novamente'),
              ),
            ],
          ),
        ),
      );
    }

    // 3) Lista vazia.
    if (provider.voos.isEmpty) {
      return Center(
        child: Text(
          provider.buscouAlgumaVez
              ? 'Nenhum voo encontrado para ${provider.aeroporto}.'
              : 'Busque um aeroporto para começar.',
          style: Theme.of(context).textTheme.bodySmall,
        ),
      );
    }

    // 4) Lista de voos.
    return RefreshIndicator(
      onRefresh: () => provider.buscarVoos(),
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: provider.voos.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, index) => _VooTile(voo: provider.voos[index]),
      ),
    );
  }
}

class _VooTile extends StatelessWidget {
  const _VooTile({required this.voo});

  final Voo voo;

  @override
  Widget build(BuildContext context) {
    final cor = voo.isPartida
        ? Theme.of(context).colorScheme.secondary
        : Theme.of(context).colorScheme.primary;

    return ListTile(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => DetalhesPage(voo: voo)),
        );
      },
      leading: CircleAvatar(
        backgroundColor: cor.withOpacity(0.15),
        child: Icon(
          voo.isPartida ? Icons.flight_takeoff : Icons.flight_land,
          color: cor,
        ),
      ),
      title: Text(
        voo.identificacao,
        style: const TextStyle(
          fontFamily: 'monospace',
          fontWeight: FontWeight.w700,
          letterSpacing: 1,
        ),
      ),
      subtitle: Text(voo.local ?? '—'),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            voo.categoriaLabel,
            style: TextStyle(color: cor, fontWeight: FontWeight.w600, fontSize: 12),
          ),
          Text(
            voo.isPartida ? (voo.partida ?? '--:--') : (voo.chegada ?? '--:--'),
            style: const TextStyle(fontFamily: 'monospace'),
          ),
        ],
      ),
    );
  }
}
