import 'package:flutter/material.dart';

import '../models/voo.dart';

class DetalhesPage extends StatelessWidget {
  const DetalhesPage({super.key, required this.voo});

  final Voo voo;

  @override
  Widget build(BuildContext context) {
    final cor = voo.isPartida
        ? Theme.of(context).colorScheme.secondary
        : Theme.of(context).colorScheme.primary;

    return Scaffold(
      appBar: AppBar(title: const Text('Detalhes do voo')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: cor.withOpacity(0.4)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  voo.identificacao,
                  style: const TextStyle(
                    fontFamily: 'monospace',
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  voo.categoriaLabel.toUpperCase(),
                  style: TextStyle(color: cor, fontWeight: FontWeight.w700, letterSpacing: 2),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _Campo(rotulo: 'Aeronave', valor: voo.tipoAeronave),
          _Campo(rotulo: voo.isPartida ? 'Destino' : 'Origem', valor: voo.local),
          _Campo(rotulo: 'Horário de partida', valor: voo.partida),
          _Campo(rotulo: 'Horário de chegada', valor: voo.chegada),
        ],
      ),
    );
  }
}

class _Campo extends StatelessWidget {
  const _Campo({required this.rotulo, required this.valor});

  final String rotulo;
  final String? valor;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(rotulo, style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 4),
          Text(
            valor ?? 'Não informado',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 18),
          ),
          const Divider(height: 24),
        ],
      ),
    );
  }
}
