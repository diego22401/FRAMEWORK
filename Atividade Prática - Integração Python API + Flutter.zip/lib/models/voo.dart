/// Modelo de um voo, espelhando o dicionário "Voo" devolvido pela API Python
/// (services/flightaware.py -> classe Voo, no projeto Flask).
class Voo {
  final String categoria; // chegadas | partidas | em_rota | partidas_programadas
  final String identificacao; // ex.: LATAM3200
  final String? tipoAeronave;
  final String? local; // origem (chegada) ou destino (partida)
  final String? partida; // horário de partida
  final String? chegada; // horário de chegada

  Voo({
    required this.categoria,
    required this.identificacao,
    this.tipoAeronave,
    this.local,
    this.partida,
    this.chegada,
  });

  factory Voo.fromJson(Map<String, dynamic> json) {
    return Voo(
      categoria: json['categoria'] as String? ?? 'desconhecida',
      identificacao: json['identificacao'] as String? ?? '—',
      tipoAeronave: json['tipo_aeronave'] as String?,
      local: json['local'] as String?,
      partida: json['partida'] as String?,
      chegada: json['chegada'] as String?,
    );
  }

  /// Rótulo amigável para mostrar na interface.
  String get categoriaLabel {
    switch (categoria) {
      case 'chegadas':
        return 'Chegada';
      case 'partidas':
        return 'Partida';
      case 'em_rota':
        return 'Em rota';
      case 'partidas_programadas':
        return 'Partida programada';
      default:
        return categoria;
    }
  }

  bool get isPartida =>
      categoria == 'partidas' || categoria == 'partidas_programadas';
}

/// Pacote completo devolvido por GET /api/voos, espelhando o
/// ResultadoBusca do Python (fonte, aeroporto, tipo_busca, total, voos).
class ResultadoBusca {
  final String fonte;
  final String aeroporto;
  final String tipoBusca;
  final int total;
  final List<Voo> voos;

  ResultadoBusca({
    required this.fonte,
    required this.aeroporto,
    required this.tipoBusca,
    required this.total,
    required this.voos,
  });

  factory ResultadoBusca.fromJson(Map<String, dynamic> json) {
    final listaVoos = (json['voos'] as List<dynamic>? ?? [])
        .map((item) => Voo.fromJson(item as Map<String, dynamic>))
        .toList();

    return ResultadoBusca(
      fonte: json['fonte'] as String? ?? '',
      aeroporto: json['aeroporto'] as String? ?? '',
      tipoBusca: json['tipo_busca'] as String? ?? '',
      total: json['total'] as int? ?? listaVoos.length,
      voos: listaVoos,
    );
  }
}
