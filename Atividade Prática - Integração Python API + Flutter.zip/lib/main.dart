import 'package:device_preview/device_preview.dart';
import 'package:flutter/foundation.dart' show kReleaseMode;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'pages/home_page.dart';
import 'providers/voo_provider.dart';

void main() {
  runApp(
    DevicePreview(
      enabled: !kReleaseMode,
      builder: (context) => const RaspaVooApp(),
    ),
  );
}

class RaspaVooApp extends StatelessWidget {
  const RaspaVooApp({super.key});

  // Paleta inspirada em painéis de aeroporto (split-flap display):
  // fundo quase-preto, âmbar para chegadas, azul-céu para partidas.
  static const corFundo = Color(0xFF0A0F1E);
  static const corSuperficie = Color(0xFF121A2E);
  static const corChegada = Color(0xFFF5A623);
  static const corPartida = Color(0xFF34C3FF);
  static const corTexto = Color(0xFFEDEFF5);
  static const corTextoMudo = Color(0xFF8A93AC);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => VooProvider(),
      child: MaterialApp(
        title: 'RaspaVoo',
        debugShowCheckedModeBanner: false,
        useInheritedMediaQuery: true,
        locale: DevicePreview.locale(context),
        builder: DevicePreview.appBuilder,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: corFundo,
          colorScheme: const ColorScheme.dark(
            primary: corChegada,
            secondary: corPartida,
            surface: corSuperficie,
            onSurface: corTexto,
          ),
          appBarTheme: const AppBarTheme(
            backgroundColor: corFundo,
            foregroundColor: corTexto,
            elevation: 0,
            centerTitle: false,
          ),
          textTheme: const TextTheme(
            titleLarge: TextStyle(color: corTexto, fontWeight: FontWeight.w700),
            bodyMedium: TextStyle(color: corTexto),
            bodySmall: TextStyle(color: corTextoMudo),
          ),
          dividerColor: const Color(0xFF232B44),
        ),
        home: const HomePage(),
      ),
    );
  }
}
