import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../models/voo.dart';

/// Service responsável exclusivamente por conversar com a API Python.
///
/// Nenhuma tela (page) chama http diretamente — tudo passa por aqui:
/// monta a URL, faz a requisição, converte o JSON e devolve objetos Dart
/// prontos para o Provider guardar.
class VooService {
  /// Monta a base da URL de acordo com onde o app está rodando:
  /// - Flutter Web -> localhost normal (é o caso descrito no enunciado)
  /// - Emulador Android -> 10.0.2.2 aponta para o localhost da máquina host
  /// - iOS simulator / desktop -> localhost normal
  static String get _baseUrl {
    if (kIsWeb) return 'http://127.0.0.1:5001';
    if (defaultTargetPlatform == TargetPlatform.android) {
      return 'http://10.0.2.2:5001';
    }
    return 'http://127.0.0.1:5001';
  }

  /// GET /api/voos?aeroporto=...&tipo=...
  Future<ResultadoBusca> buscarVoos({
    required String aeroporto,
    required String tipo,
  }) async {
    final uri = Uri.parse('$_baseUrl/api/voos').replace(queryParameters: {
      'aeroporto': aeroporto,
      'tipo': tipo,
    });

    http.Response resposta;
    try {
      resposta = await http.get(uri).timeout(const Duration(seconds: 15));
    } catch (_) {
      throw Exception(
        'Não foi possível conectar à API Python em $_baseUrl. '
        'Confira se o terminal com "python app.py" está aberto.',
      );
    }

    late final Map<String, dynamic> corpo;
    try {
      corpo = jsonDecode(utf8.decode(resposta.bodyBytes)) as Map<String, dynamic>;
    } catch (_) {
      throw Exception('A API respondeu algo que não é um JSON válido.');
    }

    if (resposta.statusCode != 200) {
      throw Exception(
        corpo['erro'] as String? ?? 'Erro ao buscar voos (${resposta.statusCode}).',
      );
    }

    return ResultadoBusca.fromJson(corpo);
  }
}
