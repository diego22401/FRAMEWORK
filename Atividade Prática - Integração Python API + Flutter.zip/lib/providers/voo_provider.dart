import 'package:flutter/foundation.dart';

import '../models/voo.dart';
import '../services/voo_service.dart';

enum TipoVoo { chegadas, partidas, todos }

extension TipoVooX on TipoVoo {
  /// Valor esperado pela query string da API (?tipo=...).
  String get valorApi {
    switch (this) {
      case TipoVoo.chegadas:
        return 'chegadas';
      case TipoVoo.partidas:
        return 'partidas';
      case TipoVoo.todos:
        return 'todos';
    }
  }

  String get rotulo {
    switch (this) {
      case TipoVoo.chegadas:
        return 'Chegadas';
      case TipoVoo.partidas:
        return 'Partidas';
      case TipoVoo.todos:
        return 'Todos';
    }
  }
}

/// Provider = "quais dados o app possui e em que estado eles estão".
///
/// Fluxo: Page chama buscarVoos() -> Provider chama a Service ->
/// Service devolve os dados -> Provider guarda + chama notifyListeners()
/// -> Page é reconstruída sozinha.
class VooProvider extends ChangeNotifier {
  VooProvider({VooService? service}) : _service = service ?? VooService();

  final VooService _service;

  String aeroporto = 'SBGR';
  TipoVoo tipo = TipoVoo.todos;

  List<Voo> voos = [];
  bool carregando = false;
  String? erro;
  String? fonte;
  int total = 0;

  bool _buscouAlgumaVez = false;
  bool get buscouAlgumaVez => _buscouAlgumaVez;

  Future<void> buscarVoos({String? novoAeroporto, TipoVoo? novoTipo}) async {
    if (novoAeroporto != null && novoAeroporto.trim().isNotEmpty) {
      aeroporto = novoAeroporto.trim().toUpperCase();
    }
    if (novoTipo != null) {
      tipo = novoTipo;
    }

    carregando = true;
    erro = null;
    _buscouAlgumaVez = true;
    notifyListeners();

    try {
      final resultado = await _service.buscarVoos(
        aeroporto: aeroporto,
        tipo: tipo.valorApi,
      );
      voos = resultado.voos;
      fonte = resultado.fonte;
      total = resultado.total;
    } catch (e) {
      erro = e.toString().replaceFirst('Exception: ', '');
      voos = [];
    } finally {
      carregando = false;
      notifyListeners();
    }
  }
}
