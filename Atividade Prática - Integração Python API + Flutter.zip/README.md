# RaspaVoo — App Flutter (Atividade Prática - Integração Python API + Flutter)

App Flutter que consome a API Python (Flask + webscraping do FlightAware) da
Aula 19 e mostra os voos de um aeroporto, com busca por código ICAO, filtro
por chegadas/partidas/todos e tela de detalhes de cada voo.

## Estrutura

```
lib/
├── main.dart                 # tema + Provider
├── models/
│   └── voo.dart               # Voo e ResultadoBusca (espelham o JSON da API)
├── services/
│   └── voo_service.dart       # única classe que faz http.get na API Python
├── providers/
│   └── voo_provider.dart      # ChangeNotifier: dados, loading, erro
└── pages/
    ├── home_page.dart         # busca + lista de voos
    └── detalhes_page.dart     # detalhes do voo selecionado
```

Fluxo, igual ao do enunciado:

```
Page → Provider → Service → API Python → Service → Provider → notifyListeners() → Page
```

## Como rodar (dois terminais, como no enunciado)

**Terminal 1 — Python**, dentro da pasta do projeto Flask:

```bash
pip install -r requirements.txt
python app.py
```

Confirme em http://127.0.0.1:5001/api que a API responde.

**Terminal 2 — Flutter**, dentro desta pasta:

```bash
flutter pub get
flutter run -d chrome
```

O app já sai buscando o aeroporto `SBGR`. Se o terminal do Python for
fechado, a tela de erro aparece com um botão "Tentar novamente".

> Rodando em emulador Android em vez de Chrome/desktop: o `voo_service.dart`
> já troca automaticamente `127.0.0.1` por `10.0.2.2`, que é como o emulador
> enxerga o localhost da máquina host.
